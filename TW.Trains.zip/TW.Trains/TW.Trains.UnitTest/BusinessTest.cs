﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TW.Trains.BLL;
using TW.Trains.Entitys.Entitys;

namespace TW.Trains.UnitTest
{
    [TestClass]
    public class BusinessTest
    {
        #region[ Properties ]
                
        protected Business _business;
        List<Route> RoutesTest;

        #endregion

        #region[ TestMethods ]

        [TestInitialize]
        public void InicializarTeste()
        {
            _business = new Business();

            #region [ Objects ]

            RoutesTest = _business.ReturnRoutesEntry(TestResource.InputTest);

            #endregion
        }

        [TestMethod]
        public void TestMethod_RouteDistance_ABC()
        {
            Route initialRoute = _business.ReturnRouteByInitials("A", "B", RoutesTest);
            Route finalRoute = _business.ReturnRouteByInitials("B", "C", RoutesTest);
            List<Route> routes = new List<Route> { initialRoute, finalRoute };
            Trip myTrip = new Trip("", routes, initialRoute.Origin, finalRoute.Destination);            

            double distaceRouteABC = myTrip.GetTotalDistance();

            Assert.IsTrue(distaceRouteABC == 9);
        }

        [TestMethod]
        public void TestMethod_RouteDistance_AD()
        {
            Route initialRoute = _business.ReturnRouteByInitials("A", "D", RoutesTest);
            List<Route> routes = new List<Route> { initialRoute };
            Trip myTrip = new Trip("", routes, initialRoute.Origin, initialRoute.Destination);

            double distaceRouteAD = myTrip.GetTotalDistance();

            Assert.IsTrue(distaceRouteAD == 5);
        }

        [TestMethod]
        public void TestMethod_RouteDistance_ADC()
        {
            Route initialRoute = _business.ReturnRouteByInitials("A", "D", RoutesTest);
            Route finalRoute = _business.ReturnRouteByInitials("D", "C", RoutesTest);
            List<Route> routes = new List<Route> { initialRoute, finalRoute };
            Trip myTrip = new Trip("", routes, initialRoute.Origin, finalRoute.Destination);            

            double distaceRouteADC = myTrip.GetTotalDistance();

            Assert.IsTrue(distaceRouteADC == 13);
        }

        [TestMethod]
        public void TestMethod_RouteDistance_AEBCD()
        {
            Route initialRoute = _business.ReturnRouteByInitials("A", "E", RoutesTest);
            Route route2 = _business.ReturnRouteByInitials("E", "B", RoutesTest);
            Route route3 = _business.ReturnRouteByInitials("B", "C", RoutesTest);           
            Route finalRoute = _business.ReturnRouteByInitials("C", "D", RoutesTest);
            List<Route> routes = new List<Route> { initialRoute, route2, route3, finalRoute };
            Trip myTrip = new Trip("", routes, initialRoute.Origin, finalRoute.Destination);         

            double distaceRouteAEBCD = myTrip.GetTotalDistance();

            Assert.IsTrue(distaceRouteAEBCD == 22);
        }

        [TestMethod]
        public void TestMethod_RouteDistance_AED()
        {
            string retorno = string.Empty;
            double distaceRouteAED = 0;

            try
            {
                Route initialRoute = _business.ReturnRouteByInitials("A", "E", RoutesTest);
                Route finalRoute = _business.ReturnRouteByInitials("E", "D", RoutesTest);
                List<Route> routes = new List<Route> { initialRoute, finalRoute };
                Trip myTrip = new Trip("", routes, initialRoute.Origin, finalRoute.Destination);

                distaceRouteAED = myTrip.GetTotalDistance();
            }
            catch (Exception ex)
            {
                retorno = ex.Message;
            }            

            Assert.IsTrue(retorno  == "NO SUCH ROUTE" && distaceRouteAED == 0);
        }

        [TestMethod]
        public void TestMethod_NumberOfTrips_ByCities_Stops()
        {
            string startCityInitial = "C";
            string endingCityInitial = "C";
            int maxStops = 3;

            List<Route> routesOriginInCityC = _business.ReturnRoutesByOriginCity(startCityInitial, this.RoutesTest);
            List<Route> routesDestinationCityC = _business.ReturnRoutesByDestinationCity(endingCityInitial, this.RoutesTest);
            List<Trip> returnTrips = _business.ReturnTripsByStops(startCityInitial, endingCityInitial, this.RoutesTest, maxStops);

            Assert.IsTrue(returnTrips.Count == 2);
        }       

        #endregion
    }
}
