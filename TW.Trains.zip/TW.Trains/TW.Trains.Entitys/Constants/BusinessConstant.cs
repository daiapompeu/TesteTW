﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TW.Trains.Entitys.Constants
{
    public static class BusinessConstant
    {
        public static string MESSAGENOROUTEFOUND = "NO SUCH ROUTE";
        public static string MESSAGEERRORFORMAT = "Error - Check format of input routes.";
    }
}
