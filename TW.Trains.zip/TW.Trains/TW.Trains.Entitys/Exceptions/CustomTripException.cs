﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TW.Trains.Entitys.Exceptions
{
    public class CustomTripException : Exception
    {
        public CustomTripException()
        {

        }

        public CustomTripException(string message)
        : base(message)
        {
        }

        public CustomTripException(string message, Exception inner)
        : base(message, inner)
        {
        }
    }
}
