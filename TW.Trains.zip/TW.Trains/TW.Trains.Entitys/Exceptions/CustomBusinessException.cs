﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TW.Trains.Entitys.Exceptions
{
    public class CustomBusinessException : Exception
    {
        public CustomBusinessException()
        {

        }

        public CustomBusinessException(string message)
        : base(message)
        {
        }

        public CustomBusinessException(string message, Exception inner)
        : base(message, inner)
        {
        }
    }
}
