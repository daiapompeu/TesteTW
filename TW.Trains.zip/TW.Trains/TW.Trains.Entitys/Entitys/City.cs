﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TW.Trains.Entitys.Entitys
{
    public class City
    {
        public string Name { get; set; }
        public string InitialLetter { get; set; }      
        
        public City(string initialLetter)
        {
            this.InitialLetter = initialLetter;
        }
    }
}
