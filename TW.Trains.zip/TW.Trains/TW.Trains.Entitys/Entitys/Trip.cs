﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TW.Trains.Entitys.Exceptions;

namespace TW.Trains.Entitys.Entitys
{
    public class Trip
    {
        #region [ Properties ]
        /// <summary>
        /// Ordered Routes
        /// </summary>
        public List<Route> Routes { get; set; }
        public City StartingCity { get; set; }
        public City EndingCity { get; set; }
        public string ID { get; set; }       
        #endregion

        #region[ Constructors ]
        public Trip(string id, List<Route> routes, City startingCity, City endingCity)
        {
            this.Routes = routes;
            this.StartingCity = startingCity;
            this.EndingCity = endingCity;
            this.ID = id;
        }

        #endregion

        #region[ Methods ]
        public double GetTotalDistance()
        {
            double totalDistance = 0;            

            try
            {
                if (this.Routes == null || this.Routes.Count == 0)
                {
                    throw new CustomTripException("Failure in method GetTotalDistance - Details: Routes is empty.");
                }
                else if (this.Routes.Count == 1)
                {
                    totalDistance = this.Routes.FirstOrDefault().Distance;
                }
                else
                {
                    totalDistance = this.Routes.Sum(r => r.Distance);
                }
            }
            catch(CustomTripException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CustomTripException(string.Format("Failure in method GetTotalDistance - Details: {0}", ex.Message), ex);
            }

            return totalDistance;
        }

        public long GetDiferentsRoutes()
        {
            return 0;
        }

        #endregion
    }
}
