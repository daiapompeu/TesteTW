﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TW.Trains.Entitys.Entitys
{
    public class Route
    {
        public City Origin { get; set; }
        public City Destination { get; set; }
        public double Distance { get; set; }
        public Route Parent { get; set; }
        public bool IsPathTraveled { get; set; }

        public string ID
        {
            get
            {
                return string.Format("{0}{1}", this.Origin.InitialLetter, this.Destination.InitialLetter);
            }
        }

        public Route(City origin, City destination, double distance)
        {
            this.Origin = origin;
            this.Destination = destination;
            this.Distance = distance;
        }        

        public override bool Equals(Object obj)
        {            
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            else
            {
                Route p = (Route)obj;
                return this.Origin.InitialLetter == p.Origin.InitialLetter && this.Destination.InitialLetter == p.Destination.InitialLetter;
            }
        }
    }
}
