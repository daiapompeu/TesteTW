﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TW.Trains.Entitys.Constants;
using TW.Trains.Entitys.Entitys;
using TW.Trains.Entitys.Exceptions;

namespace TW.Trains.BLL
{
    public class Business
    {
        /// <summary>
        /// List of distances between cities
        /// </summary>
        /// <param name="listOfDistances">String with format like: 'AB5' with separator ','</param>
        /// <returns></returns>
        public List<Route> ReturnRoutesEntry(string listOfDistances)
        {
            try
            {
                string[] arrayDistances = listOfDistances?.Split(',');

                if (arrayDistances != null && arrayDistances.Count() > 0)
                {
                    var listItens = from string item in arrayDistances
                                    select new Route(new City(item.Trim()[0].ToString()), new City(item.Trim()[1].ToString()), Convert.ToDouble(item.Trim()[2].ToString()));

                    return listItens?.ToList();
                }
                else
                {
                    return new List<Route>();
                }
            }
            catch (Exception ex)
            {
                throw new CustomBusinessException(BusinessConstant.MESSAGEERRORFORMAT, ex);
            }
        }

        public Route ReturnRouteByInitials(string initialFirst, string initialSecond, List<Route> routes)
        {
            try
            {
                var returnItem = from Route item in routes
                                 where item.Origin.InitialLetter == initialFirst && item.Destination.InitialLetter == initialSecond
                                 select item;

                return returnItem.FirstOrDefault() == null ? throw new CustomBusinessException(BusinessConstant.MESSAGENOROUTEFOUND) : returnItem.FirstOrDefault();
            }
            catch (Exception)
            {
                throw new CustomBusinessException(BusinessConstant.MESSAGENOROUTEFOUND);
            }
        }

        public List<Route> ReturnRoutesByOriginCity(string initialLetter, List<Route> routes)
        {
            try
            {
                var returnList = from Route item in routes
                                 where item.Origin.InitialLetter == initialLetter
                                 select item;

                return returnList == null ? throw new CustomBusinessException(BusinessConstant.MESSAGENOROUTEFOUND) : returnList.ToList();
            }
            catch (Exception)
            {
                throw new CustomBusinessException(BusinessConstant.MESSAGENOROUTEFOUND);
            }
        }

        public List<Route> ReturnRoutesByDestinationCity(string initialLetter, List<Route> routes)
        {
            try
            {
                var returnList = from Route item in routes
                                 where item.Destination.InitialLetter == initialLetter
                                 select item;

                return returnList == null ? throw new CustomBusinessException() : returnList.ToList();
            }
            catch (Exception)
            {
                throw new CustomBusinessException(BusinessConstant.MESSAGENOROUTEFOUND);
            }
        }        

        /// <summary>
        /// Return String of available Paths between two cities, by number of stops. The number of stops, is distinct cities of course
        /// </summary>
        /// <param name="startCityInitial">Initial Letter of start City</param>
        /// <param name="endingCityInitial">Initial Letter of ending City</param>
        /// <param name="allRoutes"></param>
        /// <param name="maxStops"></param>
        /// <returns></returns>
        public List<Trip> ReturnTripsByStops(string startCityInitial, string endingCityInitial, List<Route> allRoutes, int maxStops)
        {
            List<Route> routesStartingCity = ReturnRoutesByOriginCity(startCityInitial, allRoutes);            
            List<Route> possibleRoutes = new List<Route>();
            int countStops = 0;
            List<string> listCitiesToIgnore = new List<string>();            
            City startingCity = new City(startCityInitial);
            City endingCity = new City(endingCityInitial);
            listCitiesToIgnore.Add(startCityInitial);
            FindPathsRecurrence(routesStartingCity, maxStops, countStops, allRoutes, listCitiesToIgnore, ref possibleRoutes);

            List<Trip> avaliableTrips = ReturnAvaliableTrips(startCityInitial, endingCityInitial, possibleRoutes);
            List<Trip> returnTrips = new List<Trip>();

            foreach (var item in avaliableTrips)
            {
                List<Route> routesGet = new List<Route>();
                routesGet.Add(ReturnRouteByInitials(item.ID[0].ToString(), item.ID[1].ToString(), allRoutes));
                ReturnRoutesOrdered(item.Routes, endingCityInitial, ref routesGet);
                returnTrips.Add(new Trip(item.ID, routesGet, routesGet.ToArray()[0].Origin, routesGet.ToArray()[routesGet.ToArray().Length - 1].Destination));
            }

            return returnTrips;
        }

        private void ReturnRoutesOrdered(List<Route> routes, string endingCityInitial, ref List<Route> routesReturn)
        {
            foreach (var item in routes)
            {
                if(item.IsPathTraveled)
                {
                    continue;
                }
                else
                {
                    item.IsPathTraveled = true;
                    routesReturn.Add(item);

                    if (item.Destination.InitialLetter == endingCityInitial)
                    {
                        return;
                    }
                    else
                    {
                        var newRoutes = ReturnRoutesByOriginCity(item.Destination.InitialLetter, routes);
                        ReturnRoutesOrdered(newRoutes, endingCityInitial, ref routesReturn);
                    }
                }
            }            
        }

        private List<Trip> ReturnAvaliableTrips(string startCityInitial, string endingCityInitial, List<Route> possibleRoutes)
        {
            List<Trip> listToReturn = new List<Trip>();

            try
            {
                List<Route> routesStartingCity = ReturnRoutesByOriginCity(startCityInitial, possibleRoutes);
                City startingCity = new City(startCityInitial);
                City endingCity = new City(endingCityInitial);

                foreach (var item in routesStartingCity)
                {
                    Trip auxTrip = new Trip(string.Format("{0}{1}", item.Origin.InitialLetter, item.Destination.InitialLetter), new List<Route>(), startingCity, endingCity);
                    List<Route> routesalready = new List<Route>();
                    FindRoutesToTrip(endingCityInitial, item, possibleRoutes, ref auxTrip, ref routesalready);
                    if (auxTrip != null)
                    {
                        listToReturn.Add(auxTrip);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return listToReturn;
        }

        private void FindRoutesToTrip(string endingCityInitial, Route item, List<Route> possibleRoutes, ref Trip auxTrip, ref List<Route> routesalready)
        {
            if (routesalready?.Where(r => item.Equals(r)) == null || routesalready?.Where(r => item.Equals(r)).Count() == 0)
            {
                routesalready.Add(item);

                try
                {
                    if (item.Destination.InitialLetter != endingCityInitial)
                    {
                        var routes = ReturnRoutesByOriginCity(item.Destination.InitialLetter, possibleRoutes);
                        auxTrip.Routes.AddRange(routes);

                        foreach (var itemNext in routes)
                        {
                            FindRoutesToTrip(endingCityInitial, itemNext, possibleRoutes, ref auxTrip, ref routesalready);
                        }

                    }
                }
                catch (Exception ex)//não encontrou mais pra onde ir ???
                {
                    if (ex.Message == BusinessConstant.MESSAGENOROUTEFOUND)
                    {
                        var routesDestAux = ReturnRoutesByDestinationCity(endingCityInitial, auxTrip.Routes);

                        if (routesDestAux != null && routesDestAux.Count() > 0)
                        {
                            //encontrei rota final
                            return;
                        }
                        else
                        {
                            auxTrip = null;
                        }
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }
            else
            {
                return;
            }
        }

        private void FindPathsRecurrence(List<Route> routesStart, int maxStops, int countStops, List<Route> allRoutes, List<string> listCitiesToIgnore, ref List<Route> routesalready)
        {
            List<Route> findRoutes = new List<Route>();
            routesalready.AddRange(routesStart);
            countStops++;

            foreach (var item in routesStart)
            {
                try
                {
                    if (!listCitiesToIgnore.Contains(item.Destination.InitialLetter))
                    {
                        listCitiesToIgnore.Add(item.Destination.InitialLetter);
                        List<Route> newRoutesStartAux = ReturnRoutesByOriginCity(item.Destination.InitialLetter, allRoutes); // tenho para onde ir?
                        if (newRoutesStartAux != null && newRoutesStartAux.Count() > 0)
                        {
                            findRoutes.AddRange(newRoutesStartAux);
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message == BusinessConstant.MESSAGENOROUTEFOUND)
                    {
                        continue;
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }

            if (findRoutes == null && (routesalready == null || routesalready.Count == 0))
            {
                throw new CustomBusinessException(BusinessConstant.MESSAGENOROUTEFOUND);
            }
            else
            {
                if (findRoutes != null && findRoutes.Count() > 0 && countStops < maxStops)
                {
                    FindPathsRecurrence(findRoutes, maxStops, countStops, allRoutes, listCitiesToIgnore, ref routesalready);
                }
            }
        }
    }
}
